import {PDFDocument, PDFDict, PDFArray, PDFName, PDFRef, PDFStream} from 'pdf-lib';
import JSZip from 'jszip';
import {Inflate} from 'pako';
import {DOMParser, XMLSerializer} from '@xmldom/xmldom';

const MAX_BYTES = 20 * 1024 * 1024;
const MAX_PIXELS = 30_000_000;
const MAX_ZIP = 60 * 1024 * 1024;
const utf8 = new TextDecoder('utf-8', {fatal: true});
class CleanError extends Error {}
const fail = text => { throw new CleanError(text); };
const equal = (a, b) => a.length === b.length && a.every((value, index) => value === b[index]);
const starts = (a, b) => b.every((value, index) => a[index] === value);
const text = (bytes, offset, length) => String.fromCharCode(...bytes.subarray(offset, offset + length));
function join(parts) {
  const result = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
  let offset = 0;
  for (const part of parts) { result.set(part, offset); offset += part.length; }
  return result;
}
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  crcTable[n] = c >>> 0;
}
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function orientation(tiff) {
  if (tiff.length < 8) fail('Los datos EXIF están incompletos.');
  const order = text(tiff, 0, 2);
  if (order !== 'II' && order !== 'MM') fail('Los datos EXIF no son compatibles.');
  const little = order === 'II';
  const view = new DataView(tiff.buffer, tiff.byteOffset, tiff.byteLength);
  if (view.getUint16(2, little) !== 42) fail('Los datos EXIF no son válidos.');
  const offset = view.getUint32(4, little);
  if (offset + 2 > tiff.length) fail('Los datos EXIF están incompletos.');
  const count = view.getUint16(offset, little);
  if (count > 4096 || offset + 2 + count * 12 + 4 > tiff.length) fail('Los datos EXIF están incompletos.');
  let value = 1, found = false;
  for (let i = 0; i < count; i++) {
    const start = offset + 2 + i * 12;
    if (view.getUint16(start, little) === 274) {
      if (found || view.getUint16(start + 2, little) !== 3 || view.getUint32(start + 4, little) !== 1) fail('No se puede conservar la orientación EXIF.');
      found = true;
      value = view.getUint16(start + 8, little);
      if (value < 1 || value > 8) fail('La orientación EXIF no es válida.');
    }
  }
  return value;
}
function minimalTiff(value) {
  return new Uint8Array([73,73,42,0,8,0,0,0,1,0,18,1,3,0,1,0,0,0,value,0,0,0,0,0,0,0]);
}
function jpeg(data) {
  const parts = [data.subarray(0, 2)], removed = new Set(), preserved = new Set();
  let offset = 2, rotation = 1, exifCount = 0, dimensions = null, ended = false;
  while (offset < data.length) {
    const start = offset;
    if (data[offset] !== 255) fail('La estructura del JPG no es válida.');
    while (offset < data.length && data[offset] === 255) offset++;
    const marker = data[offset++];
    if (marker === 0xd9) {
      parts.push(new Uint8Array([255, 217])); ended = true;
      if (offset < data.length) removed.add('Datos posteriores al final de la imagen');
      break;
    }
    if (marker === undefined || marker === 0 || marker === 0xd8 || (marker >= 0xd0 && marker <= 0xd7) || offset + 2 > data.length) fail('JPG incompleto o con marcadores inesperados.');
    const length = (data[offset] << 8) | data[offset + 1];
    const end = offset + length;
    if (length < 2 || end > data.length) fail('El JPG está incompleto.');
    const payload = data.subarray(offset + 2, end);
    let segment = data.subarray(start, end), keep = true;
    if ([0xc0,0xc1,0xc2].includes(marker)) {
      if (payload.length < 6) fail('Las dimensiones del JPG no son válidas.');
      dimensions = [(payload[3] << 8) | payload[4], (payload[1] << 8) | payload[2]];
    } else if (marker >= 0xc0 && marker <= 0xcf && ![0xc4,0xc8,0xcc].includes(marker)) {
      fail('Esta variante de JPEG no está admitida.');
    }
    if (marker === 0xe1) {
      keep = false;
      removed.add('EXIF / GPS / XMP');
      if (text(payload, 0, 6) === 'Exif\0\0') {
        if (++exifCount > 1) fail('El JPG tiene varios bloques EXIF y no se puede revisar.');
        rotation = orientation(payload.subarray(6));
      }
    } else if (marker === 0xfe) { keep = false; removed.add('Comentarios JPEG'); }
    else if (marker >= 0xe0 && marker <= 0xef) {
      if (marker === 0xe0 && text(payload, 0, 5) === 'JFIF\0' && payload.length >= 14) {
        const header = join([payload.subarray(0, 12), new Uint8Array(2)]);
        segment = join([new Uint8Array([255,224,0,16]), header]);
        if (payload.length > 14) removed.add('Miniatura JPEG');
      } else if (marker === 0xe2 && text(payload, 0, 12) === 'ICC_PROFILE\0') preserved.add('Perfil de color ICC');
      else if (marker === 0xee && text(payload, 0, 5) === 'Adobe') preserved.add('Interpretación de color Adobe');
      else if (marker === 0xe2 && text(payload, 0, 4) === 'MPF\0') fail('No se admiten imágenes con varias fotografías (MPO).');
      else { keep = false; removed.add('Propiedades y miniaturas de aplicaciones'); }
    }
    if (keep) parts.push(segment);
    offset = end;
    if (marker === 0xda) {
      const scan = offset;
      while (offset < data.length) {
        if (data[offset] === 255) {
          let next = offset + 1;
          while (next < data.length && data[next] === 255) next++;
          if (next >= data.length) fail('El JPG está incompleto.');
          if (data[next] !== 0 && !(data[next] >= 0xd0 && data[next] <= 0xd7)) break;
          offset = next + 1;
        } else offset++;
      }
      parts.push(data.subarray(scan, offset));
    }
  }
  if (!ended || !dimensions) fail('El JPG está incompleto o no tiene dimensiones válidas.');
  if (rotation !== 1) {
    const payload = join([new Uint8Array([69,120,105,102,0,0]), minimalTiff(rotation)]);
    parts.splice(1, 0, join([new Uint8Array([255,225,0,payload.length + 2]), payload]));
    preserved.add('Orientación EXIF necesaria para mostrar la imagen');
  }
  return {data: join(parts), dimensions, removed, preserved, extension: '.jpg', media_type: 'image/jpeg'};
}
function pngChunk(kind, payload) {
  const type = new TextEncoder().encode(kind);
  const output = new Uint8Array(payload.length + 12);
  const view = new DataView(output.buffer);
  view.setUint32(0, payload.length); output.set(type, 4); output.set(payload, 8);
  view.setUint32(output.length - 4, crc32(output.subarray(4, output.length - 4)));
  return output;
}
function png(data) {
  const parts = [data.subarray(0, 8)], removed = new Set(), preserved = new Set();
  const structural = new Set(['IHDR','PLTE','IDAT','IEND','tRNS','cHRM','gAMA','iCCP','sRGB','sBIT','bKGD','pHYs','cICP','mDCV','cLLI']);
  const privateChunks = new Set(['tEXt','zTXt','iTXt','eXIf','tIME']);
  const view = new DataView(data.buffer, data.byteOffset, data.length);
  let offset = 8, dimensions = null, ended = false, exifCount = 0;
  while (offset + 12 <= data.length) {
    const size = view.getUint32(offset), kind = text(data, offset + 4, 4);
    const end = offset + size + 12;
    if (end > data.length) fail('El PNG está incompleto.');
    const payload = data.subarray(offset + 8, end - 4);
    if (crc32(data.subarray(offset + 4, end - 4)) !== view.getUint32(end - 4)) fail('El PNG contiene un bloque dañado.');
    if (offset === 8 && kind !== 'IHDR') fail('El PNG no tiene una cabecera válida.');
    if (kind === 'IHDR') {
      if (dimensions || size !== 13) fail('La cabecera PNG no es válida.');
      dimensions = [view.getUint32(offset + 8), view.getUint32(offset + 12)];
    }
    if (privateChunks.has(kind)) {
      removed.add('EXIF / GPS / texto / fechas PNG');
      if (kind === 'eXIf') {
        if (++exifCount > 1) fail('El PNG tiene varios bloques EXIF.');
        const rotation = orientation(payload);
        if (rotation !== 1) {
          parts.push(pngChunk('eXIf', minimalTiff(rotation)));
          preserved.add('Orientación EXIF necesaria para mostrar la imagen');
        }
      }
    } else if (structural.has(kind)) {
      parts.push(data.subarray(offset, end));
      if (['iCCP','sRGB','gAMA','cHRM','cICP','mDCV','cLLI'].includes(kind)) preserved.add('Perfil e interpretación de color');
    } else fail('Este PNG tiene animación o bloques especiales que no se pueden revisar.');
    offset = end;
    if (kind === 'IEND') {
      ended = true;
      if (offset < data.length) removed.add('Datos posteriores al final de la imagen');
      break;
    }
  }
  if (!ended || !dimensions) fail('El PNG está incompleto.');
  return {data: join(parts), dimensions, removed, preserved, extension: '.png', media_type: 'image/png'};
}
async function digest(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(value => value.toString(16).padStart(2, '0')).join('');
}
async function imageSnapshot(data, mime, dimensions) {
  if (!dimensions[0] || !dimensions[1] || dimensions[0] * dimensions[1] > MAX_PIXELS) fail('Solo se admiten imágenes de hasta 30 megapíxeles.');
  if (!globalThis.createImageBitmap || !globalThis.OffscreenCanvas) fail('Actualiza tu navegador para comprobar las imágenes con seguridad.');
  const bitmap = await createImageBitmap(new Blob([data], {type: mime}), {imageOrientation: 'from-image'});
  try {
    if (bitmap.width * bitmap.height > MAX_PIXELS) fail('La imagen supera el límite de píxeles.');
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    const ctx = canvas.getContext('2d', {willReadFrequently: true});
    ctx.drawImage(bitmap, 0, 0);
    const result = `${bitmap.width}x${bitmap.height}:${await digest(ctx.getImageData(0, 0, bitmap.width, bitmap.height).data)}`;
    canvas.width = canvas.height = 1;
    return result;
  } finally { bitmap.close(); }
}
async function cleanImage(data) {
  let result;
  if (starts(data, [255,216])) result = jpeg(data);
  else if (starts(data, [137,80,78,71,13,10,26,10])) result = png(data);
  else fail('Esta imagen debe ser JPG o PNG.');
  const before = await imageSnapshot(data, result.media_type, result.dimensions);
  if (before !== await imageSnapshot(result.data, result.media_type, result.dimensions)) fail('No se pudo conservar la apariencia de la imagen. Tu original sigue intacto.');
  result.removed = [...result.removed]; result.preserved = [...result.preserved];
  result.verification = 'Píxeles y dimensiones mostrados por el navegador iguales al original. Flujo de imagen sin recomprimir.';
  delete result.dimensions;
  return result;
}

function readZip(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 0x06054b50 && i + 22 + view.getUint16(i + 20, true) === bytes.length) { eocd = i; break; }
  }
  if (eocd < 0) fail('El contenedor Word está incompleto.');
  const count = view.getUint16(eocd + 10, true), centralSize = view.getUint32(eocd + 12, true);
  let offset = view.getUint32(eocd + 16, true), total = 0;
  if (!count || count > 1000 || view.getUint16(eocd + 4, true) !== 0 || view.getUint16(eocd + 6, true) !== 0 || view.getUint16(eocd + 8, true) !== count || offset + centralSize !== eocd) fail('El Word supera los límites o utiliza un contenedor no admitido.');
  const records = [], names = new Set();
  for (let i = 0; i < count; i++) {
    if (offset + 46 > eocd || view.getUint32(offset, true) !== 0x02014b50) fail('El contenedor Word no es válido.');
    const flags = view.getUint16(offset + 8, true), method = view.getUint16(offset + 10, true);
    const crc = view.getUint32(offset + 16, true), compressed = view.getUint32(offset + 20, true), size = view.getUint32(offset + 24, true);
    const nameLength = view.getUint16(offset + 28, true), extraLength = view.getUint16(offset + 30, true), commentLength = view.getUint16(offset + 32, true);
    const local = view.getUint32(offset + 42, true), end = offset + 46 + nameLength + extraLength + commentLength;
    if (end > eocd || flags & 1 || ![0,8].includes(method) || size === 0xffffffff || compressed === 0xffffffff) fail('No se admiten Word cifrados ni ZIP especiales.');
    const rawName = bytes.subarray(offset + 46, offset + 46 + nameLength);
    if (!(flags & 0x800) && rawName.some(value => value > 127)) fail('El Word contiene nombres internos con codificación no admitida.');
    const name = utf8.decode(rawName);
    if (!name || names.has(name) || name.startsWith('/') || name.includes('\\') || name.split('/').includes('..') || name.includes('\0')) fail('El Word contiene rutas internas no válidas o duplicadas.');
    names.add(name); total += size;
    if (total > MAX_ZIP) fail('El Word supera los 60 MB descomprimidos.');
    if (local + 30 > offset || view.getUint32(local, true) !== 0x04034b50 || view.getUint16(local + 6, true) !== flags || view.getUint16(local + 8, true) !== method) fail('El Word tiene cabeceras ZIP inconsistentes.');
    const localNameLength = view.getUint16(local + 26, true), localExtra = view.getUint16(local + 28, true);
    const start = local + 30 + localNameLength + localExtra;
    if (!equal(rawName, bytes.subarray(local + 30, local + 30 + localNameLength)) || start + compressed > view.getUint32(eocd + 16, true)) fail('El Word tiene entradas incompletas.');
    records.push({name, start, compressed, size, method, crc}); offset = end;
  }
  if (offset !== eocd) fail('El índice ZIP no es válido.');
  const contents = new Map();
  for (const entry of records) {
    const source = bytes.subarray(entry.start, entry.start + entry.compressed);
    let content;
    if (entry.method === 0) content = source.slice();
    else {
      const inflate = new Inflate({raw: true, chunkSize: 65536}), chunks = [];
      let length = 0;
      inflate.onData = chunk => {
        length += chunk.length;
        if (length > entry.size || length > MAX_ZIP) fail('El Word excede sus tamaños de descompresión declarados.');
        chunks.push(chunk);
      };
      inflate.push(source, true);
      if (inflate.err || !inflate.ended) fail('No se pudo descomprimir el Word.');
      content = join(chunks);
    }
    if (content.length !== entry.size || crc32(content) !== entry.crc) fail('El Word contiene una entrada dañada.');
    contents.set(entry.name, content);
  }
  return contents;
}
function decodeXml(content) {
  if (starts(content, [255,254])) return new TextDecoder('utf-16le', {fatal: true}).decode(content);
  if (starts(content, [254,255])) return new TextDecoder('utf-16be', {fatal: true}).decode(content);
  return utf8.decode(content);
}
function parseXml(content) {
  const value = decodeXml(content);
  if (/<!DOCTYPE|<!ENTITY/i.test(value)) fail('El Word tiene declaraciones XML no admitidas.');
  const doc = new DOMParser({onError: () => fail('El Word contiene XML dañado.')}).parseFromString(value, 'application/xml');
  if (!doc.documentElement) fail('Falta la estructura XML del Word.');
  return doc;
}
function normalizedTarget(base, target) {
  const parts = (target.startsWith('/') ? target : base + '/' + target).split('/'), result = [];
  for (const part of parts) {
    if (!part || part === '.') continue;
    if (part === '..') result.pop(); else result.push(part);
  }
  return result.join('/');
}
async function cleanDocx(data) {
  const contents = readZip(data), original = new Map(contents), removed = new Set(), preserved = new Set();
  if (!contents.has('word/document.xml') || !contents.has('[Content_Types].xml')) fail('El archivo no es un documento DOCX válido.');
  const types = parseXml(contents.get('[Content_Types].xml'));
  const typeEntries = Array.from(types.documentElement.childNodes).filter(node => node.nodeType === 1);
  const mainType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml';
  if (!typeEntries.some(node => node.getAttribute('PartName') === '/word/document.xml' && node.getAttribute('ContentType') === mainType)) fail('Solo se admiten DOCX estándar sin macros.');
  for (const node of typeEntries) {
    const type = node.getAttribute('ContentType') || '';
    if (/core-properties|extended-properties|custom-properties/.test(type) && !(node.getAttribute('PartName') || '').startsWith('/docProps/')) fail('Este Word almacena propiedades fuera de las rutas estándar y no se puede limpiar con seguridad.');
  }
  for (const [name, content] of contents) {
    if (/^(_xmlsignatures|word\/embeddings)\//.test(name) || /comments|vbaProject\.bin/i.test(name)) fail('Este Word contiene firmas, comentarios, macros o adjuntos no admitidos.');
    if (name.endsWith('.xml')) {
      const doc = parseXml(content), nodes = doc.getElementsByTagName('*');
      if (nodes.length > 200000) fail('La estructura del Word es demasiado grande.');
      const blocked = new Set(['ins','del','moveFrom','moveTo','trackRevisions','commentRangeStart','commentReference','fldSimple','instrText','dataBinding']);
      for (let i = 0; i < nodes.length; i++) {
        const tag = nodes[i].localName;
        if (blocked.has(tag) || tag.endsWith('PrChange')) fail('Este Word tiene revisiones, campos automáticos o datos vinculados que podrían cambiar.');
      }
    }
  }
  const deleted = new Set([...contents.keys()].filter(name => /^(docProps|customXml)\//.test(name)));
  if (deleted.size) removed.add('Propiedades Word, miniaturas y XML personalizado sin vínculos al contenido');
  for (const name of deleted) contents.delete(name);
  for (const [name, content] of contents) {
    if (name === '[Content_Types].xml' || name.endsWith('.rels')) {
      const doc = parseXml(content), nodes = Array.from(doc.documentElement.childNodes).filter(node => node.nodeType === 1);
      let changed = false;
      for (const node of nodes) {
        let target;
        if (name === '[Content_Types].xml') target = (node.getAttribute('PartName') || '').replace(/^\//, '');
        else {
          const base = name === '_rels/.rels' ? '' : name.split('/').slice(0, -2).join('/');
          target = normalizedTarget(base, node.getAttribute('Target') || '');
        }
        if (deleted.has(target)) { doc.documentElement.removeChild(node); changed = true; }
      }
      if (changed) {
        const serialized = new XMLSerializer().serializeToString(doc).replace(/^<\?xml[^?]*\?>\s*/, '');
        contents.set(name, new TextEncoder().encode('<?xml version="1.0" encoding="UTF-8"?>\n' + serialized));
      }
    }
    if (name.startsWith('word/media/') && !name.endsWith('/')) {
      const image = await cleanImage(content);
      contents.set(name, image.data); image.removed.forEach(value => removed.add(value)); image.preserved.forEach(value => preserved.add(value));
    }
  }
  const archive = new JSZip();
  for (const [name, content] of contents) archive.file(name, content, {date: new Date(Date.UTC(1980, 0, 1)), createFolders: false, comment: '', unixPermissions: 0o100644});
  const cleaned = await archive.generateAsync({type: 'uint8array', compression: 'DEFLATE', compressionOptions: {level: 6}, platform: 'UNIX', comment: ''});
  const check = readZip(cleaned);
  for (const [name, content] of original) {
    if (deleted.has(name) || name.endsWith('.rels') || name === '[Content_Types].xml' || name.startsWith('word/media/')) continue;
    if (!check.has(name) || !equal(check.get(name), content)) fail('La comprobación del contenido del Word falló.');
  }
  removed.add('Fechas y comentarios del contenedor Word'); preserved.add('Texto, estilos, tablas y estructura del documento');
  return {data: cleaned, extension: '.docx', media_type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    removed: [...removed], preserved: [...preserved], verification: 'XML del contenido idéntico, imágenes verificadas y contenedor ZIP válido.'};
}

async function cleanPdf(data) {
  const doc = await PDFDocument.load(data, {updateMetadata: false, throwOnInvalidObject: true});
  const removed = new Set(), ctx = doc.context;
  const annotations = new Set(['Text','Link','FreeText','Line','Square','Circle','Polygon','PolyLine','Highlight','Underline','Squiggly','StrikeOut','Stamp','Caret','Ink','Popup','FileAttachment','Sound','Movie','Widget','Screen','PrinterMark','TrapNet','Watermark','3D','Redact'].map(value => '/' + value));
  if (doc.isEncrypted || ctx.trailerInfo.Encrypt) fail('No se admiten PDF cifrados.');
  if (!doc.getPageCount() || doc.getPageCount() > 50) fail('El PDF debe tener entre 1 y 50 páginas.');
  if (doc.catalog.has(PDFName.of('AcroForm')) || doc.catalog.has(PDFName.of('Collection'))) fail('No se admiten PDF con formularios, firmas o portfolios.');
  let nodes = 0;
  const seen = new Set(), pending = ctx.enumerateIndirectObjects().map(([, object]) => object);
  while (pending.length) {
    const object = pending.pop();
    if (!object || seen.has(object)) continue;
    seen.add(object);
    if (++nodes > 200000) fail('El PDF es demasiado complejo para revisarlo.');
    if (object instanceof PDFArray) { pending.push(...object.asArray()); continue; }
    const dictionary = object instanceof PDFStream ? object.dict : object;
    if (!(dictionary instanceof PDFDict)) continue;
    const type = dictionary.lookup(PDFName.of('Type'))?.toString();
    const action = dictionary.lookup(PDFName.of('S'))?.toString();
    if (dictionary.lookup(PDFName.of('Subtype'))?.toString() === '/Image') {
      const width = dictionary.lookup(PDFName.of('Width'))?.asNumber?.();
      const height = dictionary.lookup(PDFName.of('Height'))?.asNumber?.();
      if (!width || !height || width * height > MAX_PIXELS) fail('Una imagen interna del PDF supera el límite de 30 megapíxeles.');
    }
    if (['/Sig','/EmbeddedFile','/Filespec'].includes(type) || ['/JavaScript','/Launch'].includes(action)
       || dictionary.has(PDFName.of('EF')) || dictionary.has(PDFName.of('JS')) || dictionary.has(PDFName.of('JavaScript'))
       || dictionary.lookup(PDFName.of('Subtype'))?.toString() === '/FileAttachment') fail('El PDF contiene firmas, adjuntos o acciones no admitidas.');
    for (const key of ['Metadata','PieceInfo','LastModified']) {
      if (dictionary.has(PDFName.of(key))) { dictionary.delete(PDFName.of(key)); removed.add('XMP y propiedades de aplicaciones'); }
    }
    if (type === '/Annot' || annotations.has(dictionary.lookup(PDFName.of('Subtype'))?.toString())) {
      for (const key of ['T','M','CreationDate','NM']) {
        if (dictionary.has(PDFName.of(key))) { dictionary.delete(PDFName.of(key)); removed.add('Autor y fechas de anotaciones'); }
      }
    }
    pending.push(...dictionary.values());
  }
  if (ctx.trailerInfo.Info) removed.add('Propiedades PDF (autor, título, fechas y software)');
  if (ctx.trailerInfo.ID) removed.add('Identificadores originales del PDF');
  ctx.trailerInfo.Info = undefined; ctx.trailerInfo.ID = undefined;
  // pdf-lib serializes unused objects too. Sweep unreachable metadata/content objects.
  const reachable = new Set(), objects = new Set(), stack = [ctx.trailerInfo.Root];
  while (stack.length) {
    let object = stack.pop();
    if (object instanceof PDFRef) {
      const key = object.toString();
      if (reachable.has(key)) continue;
      reachable.add(key); object = ctx.lookup(object);
    }
    if (!object || objects.has(object)) continue;
    objects.add(object);
    if (objects.size > 200000) fail('El PDF es demasiado complejo.');
    if (object instanceof PDFArray) stack.push(...object.asArray());
    else {
      const dictionary = object instanceof PDFStream ? object.dict : object;
      if (dictionary instanceof PDFDict) stack.push(...dictionary.values());
    }
  }
  for (const [reference] of ctx.enumerateIndirectObjects()) if (!reachable.has(reference.toString())) ctx.delete(reference);
  const cleaned = await doc.save({useObjectStreams: false, addDefaultPage: false, updateFieldAppearances: false});
  return {data: cleaned, extension: '.pdf', media_type: 'application/pdf', removed: [...removed],
    preserved: ['Texto, imágenes, enlaces y anotaciones visibles'], verification: 'Pendiente de comprobar texto y apariencia de cada página.'};
}

self.onmessage = async event => {
  try {
    const {buffer, extension} = event.data, data = new Uint8Array(buffer);
    if (!data.length || data.length > MAX_BYTES) fail('El archivo debe tener contenido y pesar como máximo 20 MB.');
    let result;
    if (['.jpg','.jpeg'].includes(extension) && starts(data, [255,216])) result = await cleanImage(data);
    else if (extension === '.png' && starts(data, [137,80,78,71,13,10,26,10])) result = await cleanImage(data);
    else if (extension === '.pdf' && text(data, 0, 5) === '%PDF-') result = await cleanPdf(data);
    else if (extension === '.docx' && starts(data, [80,75,3,4])) result = await cleanDocx(data);
    else fail('Selecciona un PDF, DOCX, JPG o PNG cuyo contenido corresponda a su extensión.');
    if (result.data.length > MAX_BYTES) fail('La copia supera el límite de 20 MB.');
    self.postMessage({result}, [result.data.buffer]);
  } catch (error) {
    const message = error instanceof CleanError ? error.message : /encrypted/i.test(error.message || '') ? 'No se admiten archivos cifrados.' : 'El archivo está dañado o no es compatible. Tu original sigue intacto.';
    self.postMessage({error: message});
  }
};
