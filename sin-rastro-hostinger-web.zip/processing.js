import * as pdfjs from './vendor/pdfjs/pdf.min.mjs';

pdfjs.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdfjs/pdf.worker.min.mjs', import.meta.url).href;
const MAX_BYTES = 20 * 1024 * 1024;
const MAX_PIXELS = 30_000_000;

async function hash(data) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', data))].map(value => value.toString(16).padStart(2, '0')).join('');
}
async function pdfSnapshot(data, signal) {
  const assets = new URL('./vendor/pdfjs/', import.meta.url);
  const loading = pdfjs.getDocument({data: data.slice(), isEvalSupported: false, enableXfa: false,
    stopAtErrors: true, cMapUrl: new URL('cmaps/', assets).href, cMapPacked: true,
    standardFontDataUrl: new URL('standard_fonts/', assets).href, wasmUrl: new URL('wasm/', assets).href,
    iccUrl: new URL('iccs/', assets).href, useSystemFonts: false, maxImageSize: MAX_PIXELS,
    canvasMaxAreaInBytes: MAX_PIXELS * 4});
  const abort = () => { void loading.destroy(); };
  signal.addEventListener('abort', abort, {once: true});
  try {
    const doc = await loading.promise;
    if (doc.numPages < 1 || doc.numPages > 50) throw new Error('El PDF debe tener entre 1 y 50 páginas.');
    const result = [];
    for (let index = 1; index <= doc.numPages; index++) {
      signal.throwIfAborted();
      const page = await doc.getPage(index), viewport = page.getViewport({scale: 1});
      const width = Math.ceil(viewport.width), height = Math.ceil(viewport.height);
      if (width <= 0 || height <= 0 || width * height > MAX_PIXELS) throw new Error('Una página del PDF supera el tamaño que se puede verificar.');
      const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
      try {
        const context = canvas.getContext('2d', {willReadFrequently: true});
        await page.render({canvasContext: context, viewport, background: 'rgba(255,255,255,0)'}).promise;
        const pixels = await hash(context.getImageData(0, 0, width, height).data);
        const text = await page.getTextContent();
        const annotations = await page.getAnnotations();
        const visibleAnnotations = annotations.map(item => ({subtype: item.subtype, rect: item.rect,
          contents: item.contentsObj?.str, url: item.url, dest: item.dest, fieldValue: item.fieldValue}));
        result.push(JSON.stringify({width,height,pixels,text: text.items.map(item => ({str:item.str,transform:item.transform})),annotations:visibleAnnotations}));
      } finally { canvas.width = canvas.height = 1; page.cleanup(); }
    }
    return JSON.stringify(result);
  } finally {
    signal.removeEventListener('abort', abort);
    await loading.destroy();
  }
}
function workerClean(data, extension, signal) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL('./cleaner-worker.js', import.meta.url));
    let done = false;
    function finish(error, result) {
      if (done) return; done = true;
      worker.terminate(); signal.removeEventListener('abort', cancel);
      if (error) reject(error); else resolve(result);
    }
    const cancel = () => finish(new Error('La operación se canceló. Tu archivo original sigue intacto.'));
    signal.addEventListener('abort', cancel, {once:true});
    worker.onmessage = event => event.data.error ? finish(new Error(event.data.error)) : finish(null, event.data.result);
    worker.onerror = () => finish(new Error('El archivo no se pudo revisar con los recursos de este navegador. El original sigue intacto.'));
    const copy = data.slice();
    worker.postMessage({buffer: copy.buffer, extension}, [copy.buffer]);
  });
}

export async function cleanInBrowser(file, onProgress = () => {}, externalSignal) {
  if (!globalThis.isSecureContext || !crypto.subtle) throw new Error('Abre la aplicación mediante HTTPS para limpiar los archivos con seguridad.');
  if (!file.size || file.size > MAX_BYTES) throw new Error('El archivo debe tener contenido y pesar como máximo 20 MB.');
  const extension = '.' + file.name.split('.').pop().toLowerCase();
  if (!['.pdf','.docx','.jpg','.jpeg','.png'].includes(extension)) throw new Error('Formatos admitidos: PDF, DOCX, JPG y PNG.');
  const controller = new AbortController(), signal = controller.signal;
  const cancel = () => controller.abort();
  externalSignal?.addEventListener('abort', cancel, {once: true});
  if (externalSignal?.aborted) cancel();
  const timeout = setTimeout(cancel, 90000);
  try {
    signal.throwIfAborted();
    const data = new Uint8Array(await file.arrayBuffer());
    let before;
    if (extension === '.pdf') { onProgress('Comprobando el texto y la apariencia del PDF original…'); before = await pdfSnapshot(data, signal); }
    signal.throwIfAborted();
    onProgress('Retirando metadatos y comprobando el contenido en tu navegador…');
    const result = await workerClean(data, extension, signal);
    if (extension === '.pdf') {
      onProgress('Verificando cada página de la copia limpia…');
      const after = await pdfSnapshot(result.data, signal);
      if (before !== after) throw new Error('No se pudo conservar el texto, la apariencia o las anotaciones del PDF. El original sigue intacto.');
      result.verification = 'Mismas páginas, texto, enlaces y representación visual a 72 ppp en este navegador.';
    }
    signal.throwIfAborted();
    return result;
  } catch (error) {
    if (signal.aborted) throw new Error('La operación se canceló o superó 90 segundos. Tu original sigue intacto; prueba con un archivo más pequeño.');
    if (error.name === 'PasswordException') throw new Error('No se admiten PDF cifrados.');
    if (error.name === 'InvalidPDFException') throw new Error('El PDF está dañado o no se puede leer.');
    throw error;
  } finally { clearTimeout(timeout); externalSignal?.removeEventListener('abort', cancel); }
}
