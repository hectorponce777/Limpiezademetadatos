import {cleanInBrowser} from './processing.js';
'use strict';
const $ = id => document.getElementById(id);
let file = null, downloadUrl = null, busy = false;
const allowed = new Set(['pdf', 'docx', 'jpg', 'jpeg', 'png']);
function resetResult() {
  if (downloadUrl) URL.revokeObjectURL(downloadUrl);
  downloadUrl = null;
  $('download').removeAttribute('href');
  $('result').hidden = true;
  $('message').hidden = true;
  document.querySelector('.step').textContent = '01 / 03';
}
function message(text, error = false) {
  $('message').textContent = text;
  $('message').className = error ? 'message error' : 'message';
  $('message').hidden = false;
}
function selectFile(next) {
  if (busy) return;
  resetResult();
  file = null;
  $('selection').hidden = true;
  $('clean-button').disabled = true;
  if (!next) return;
  const extension = next.name.split('.').pop().toLowerCase();
  if (!allowed.has(extension)) return message('Selecciona un PDF, DOCX, JPG o PNG.', true);
  if (next.size > 20 * 1024 * 1024 || next.size === 0) return message('El archivo debe tener contenido y pesar como máximo 20 MB.', true);
  file = next;
  $('file-type').textContent = extension.toUpperCase();
  $('file-name').textContent = file.name;
  $('file-size').textContent = (file.size / 1024 / 1024).toFixed(2) + ' MB';
  $('selection').hidden = false;
  $('clean-button').disabled = false;
}
$('file-input').addEventListener('change', event => selectFile(event.target.files[0]));
$('remove-file').addEventListener('click', () => { $('file-input').value = ''; selectFile(null); });
const zone = $('drop-zone');
['dragenter', 'dragover'].forEach(type => zone.addEventListener(type, event => { event.preventDefault(); if (!busy) zone.classList.add('dragover'); }));
['dragleave', 'drop'].forEach(type => zone.addEventListener(type, event => { event.preventDefault(); zone.classList.remove('dragover'); }));
zone.addEventListener('drop', event => {
  if (busy) return;
  $('file-input').value = '';
  if (event.dataTransfer.files.length !== 1) { selectFile(null); return message('Selecciona un solo archivo a la vez.', true); }
  selectFile(event.dataTransfer.files[0]);
});
window.addEventListener('dragover', event => event.preventDefault());
window.addEventListener('drop', event => event.preventDefault());
function fillList(id, values, empty) {
  $(id).replaceChildren();
  (values.length ? values : [empty]).forEach(text => {
    const li = document.createElement('li');
    li.textContent = text;
    $(id).append(li);
  });
}
$('clean-button').addEventListener('click', async () => {
  if (!file || busy) return;
  resetResult();
  busy = true;
  $('clean-button').disabled = true;
  $('file-input').disabled = true;
  $('remove-file').disabled = true;
  $('clean-button').textContent = 'Limpiando y comprobando…';
  $('cancel-button').hidden = false;
  document.querySelector('.step').textContent = '02 / 03';
  message('Estamos comprobando tu archivo en el navegador. No se subirá al hosting.');
  const controller = new AbortController();
  $('cancel-button').onclick = () => controller.abort();
  try {
    const report = await cleanInBrowser(file, text => message(text), controller.signal);
    const extension = report.extension;
    const blob = new Blob([report.data], {type: report.media_type});
    downloadUrl = URL.createObjectURL(blob);
    $('download').href = downloadUrl;
    $('download').download = 'archivo-limpio' + (extension === '.jpeg' ? '.jpg' : extension);
    $('verification').textContent = report.verification;
    fillList('removed-list', report.removed, 'No se encontraron metadatos eliminables dentro del alcance de esta versión.');
    fillList('preserved-list', report.preserved, 'Contenido y apariencia de la imagen.');
    $('message').hidden = true;
    $('result').hidden = false;
    document.querySelector('.step').textContent = '03 / 03';
  } catch (error) {
    message(error.name === 'AbortError' ? 'La comprobación tardó demasiado. El original sigue intacto; prueba con un archivo más pequeño.' : error.message, true);
    document.querySelector('.step').textContent = '01 / 03';
  } finally {
    $('cancel-button').hidden = true;
    $('cancel-button').onclick = null;
    busy = false;
    $('clean-button').disabled = false;
    $('file-input').disabled = false;
    $('remove-file').disabled = false;
    $('clean-button').textContent = 'Limpiar metadatos →';
  }
});
window.addEventListener('pagehide', () => { if (downloadUrl) URL.revokeObjectURL(downloadUrl); });
